import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

const permissions = [
  ['dashboard', 'view'],
  ['users', 'view'],
  ['users', 'create'],
  ['users', 'edit'],
  ['users', 'manage'],
  ['roles', 'view'],
  ['roles', 'manage'],
  ['customers', 'view'],
  ['customers', 'create'],
  ['customers', 'edit'],
  ['collections', 'view'],
  ['collections', 'create'],
  ['collections', 'edit'],
  ['collections', 'cancel'],
  ['weighing', 'view'],
  ['weighing', 'create'],
  ['sorting', 'view'],
  ['sorting', 'create'],
  ['processing', 'view'],
  ['processing', 'create'],
  ['inventory', 'view'],
  ['inventory', 'create'],
  ['sales', 'view'],
  ['sales', 'create'],
  ['sales', 'cancel'],
  ['finance', 'view'],
  ['finance', 'create'],
  ['finance', 'pay'],
  ['finance', 'receive'],
  ['reports', 'view'],
  ['audit', 'view']
] as const;

async function main() {
  const company = await prisma.company.upsert({
    where: { id: '11111111-1111-1111-1111-111111111111' },
    update: {},
    create: {
      id: '11111111-1111-1111-1111-111111111111',
      legalName: 'Descarte Ideal',
      tradeName: 'Descarte Ideal',
      email: 'admin@descarteideal.local'
    }
  });

  for (const [module, action] of permissions) {
    await prisma.permission.upsert({
      where: { module_action: { module, action } },
      update: {},
      create: {
        module,
        action,
        description: `${module}.${action}`
      }
    });
  }

  const adminRole = await prisma.role.upsert({
    where: {
      companyId_name: {
        companyId: company.id,
        name: 'Administrador'
      }
    },
    update: {},
    create: {
      companyId: company.id,
      name: 'Administrador',
      description: 'Acesso total ao ERP'
    }
  });

  const allPermissions = await prisma.permission.findMany();

  for (const permission of allPermissions) {
    await prisma.rolePermission.upsert({
      where: {
        roleId_permissionId: {
          roleId: adminRole.id,
          permissionId: permission.id
        }
      },
      update: {},
      create: {
        roleId: adminRole.id,
        permissionId: permission.id
      }
    });
  }

  const passwordHash = await bcrypt.hash('Admin@123456', 12);

  await prisma.user.upsert({
    where: {
      companyId_email: {
        companyId: company.id,
        email: 'admin@descarteideal.local'
      }
    },
    update: {
      roleId: adminRole.id,
      passwordHash,
      status: 'ACTIVE'
    },
    create: {
      companyId: company.id,
      roleId: adminRole.id,
      name: 'Administrador',
      email: 'admin@descarteideal.local',
      passwordHash,
      status: 'ACTIVE'
    }
  });

  console.log('Seed concluído.');
  console.log('Login: admin@descarteideal.local');
  console.log('Senha inicial: Admin@123456');
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
