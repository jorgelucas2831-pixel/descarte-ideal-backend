import {
  Body,
  Controller,
  Get,
  Param,
  Patch,
  Post,
  Req,
  UseGuards,
} from '@nestjs/common';
import { CustomersService } from './customers.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { PermissionsGuard } from '../auth/permissions.guard';
import { RequirePermissions } from '../auth/permissions.decorator';
import { CreateCustomerDto } from './dto/create-customer.dto';
import { UpdateCustomerDto } from './dto/update-customer.dto';
import { CreateCollectionPointDto } from './dto/create-collection-point.dto';
import { UpdateCollectionPointDto } from './dto/update-collection-point.dto';

@Controller('customers')
@UseGuards(JwtAuthGuard, PermissionsGuard)
export class CustomersController {
  constructor(private readonly service: CustomersService) {}

  @Get()
  @RequirePermissions('customers.view')
  findAll(@Req() req: any) {
    return this.service.findAll(req.user.companyId);
  }

  @Get(':id')
  @RequirePermissions('customers.view')
  findOne(@Req() req: any, @Param('id') id: string) {
    return this.service.findOne(req.user.companyId, id);
  }

  @Post()
  @RequirePermissions('customers.create')
  create(@Req() req: any, @Body() dto: CreateCustomerDto) {
    return this.service.create(req.user.companyId, dto);
  }

  @Patch(':id')
  @RequirePermissions('customers.edit')
  update(
    @Req() req: any,
    @Param('id') id: string,
    @Body() dto: UpdateCustomerDto,
  ) {
    return this.service.update(req.user.companyId, id, dto);
  }

  @Get(':id/collection-points')
  @RequirePermissions('customers.view')
  listPoints(@Req() req: any, @Param('id') id: string) {
    return this.service.listPoints(req.user.companyId, id);
  }

  @Post(':id/collection-points')
  @RequirePermissions('customers.create')
  createPoint(
    @Req() req: any,
    @Param('id') id: string,
    @Body() dto: CreateCollectionPointDto,
  ) {
    return this.service.createPoint(req.user.companyId, id, dto);
  }

  @Patch(':id/collection-points/:pointId')
  @RequirePermissions('customers.edit')
  updatePoint(
    @Req() req: any,
    @Param('id') id: string,
    @Param('pointId') pointId: string,
    @Body() dto: UpdateCollectionPointDto,
  ) {
    return this.service.updatePoint(req.user.companyId, id, pointId, dto);
  }
}
