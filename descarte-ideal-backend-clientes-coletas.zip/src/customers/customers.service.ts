import {
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateCustomerDto } from './dto/create-customer.dto';
import { UpdateCustomerDto } from './dto/update-customer.dto';
import { CreateCollectionPointDto } from './dto/create-collection-point.dto';
import { UpdateCollectionPointDto } from './dto/update-collection-point.dto';

@Injectable()
export class CustomersService {
  constructor(private readonly prisma: PrismaService) {}

  findAll(companyId: string) {
    return this.prisma.wasteGenerator.findMany({
      where: { companyId },
      include: { collectionPoints: { where: { active: true } } },
      orderBy: { name: 'asc' },
    });
  }

  async findOne(companyId: string, id: string) {
    const customer = await this.prisma.wasteGenerator.findFirst({
      where: { id, companyId },
      include: { collectionPoints: true },
    });
    if (!customer) throw new NotFoundException('Cliente/gerador não encontrado');
    return customer;
  }

  async create(companyId: string, dto: CreateCustomerDto) {
    if (dto.document) {
      const exists = await this.prisma.wasteGenerator.findFirst({
        where: { companyId, document: dto.document },
      });
      if (exists) throw new ConflictException('Documento já cadastrado');
    }

    return this.prisma.wasteGenerator.create({
      data: { companyId, ...dto },
    });
  }

  async update(companyId: string, id: string, dto: UpdateCustomerDto) {
    await this.findOne(companyId, id);
    return this.prisma.wasteGenerator.update({
      where: { id },
      data: dto,
    });
  }

  async createPoint(
    companyId: string,
    generatorId: string,
    dto: CreateCollectionPointDto,
  ) {
    await this.findOne(companyId, generatorId);
    return this.prisma.collectionPoint.create({
      data: {
        generatorId,
        ...dto,
        latitude: dto.latitude,
        longitude: dto.longitude,
      },
    });
  }

  async updatePoint(
    companyId: string,
    generatorId: string,
    pointId: string,
    dto: UpdateCollectionPointDto,
  ) {
    await this.findOne(companyId, generatorId);

    const point = await this.prisma.collectionPoint.findFirst({
      where: { id: pointId, generatorId },
    });
    if (!point) throw new NotFoundException('Ponto de coleta não encontrado');

    return this.prisma.collectionPoint.update({
      where: { id: pointId },
      data: dto,
    });
  }

  async listPoints(companyId: string, generatorId: string) {
    await this.findOne(companyId, generatorId);
    return this.prisma.collectionPoint.findMany({
      where: { generatorId },
      orderBy: { name: 'asc' },
    });
  }
}
