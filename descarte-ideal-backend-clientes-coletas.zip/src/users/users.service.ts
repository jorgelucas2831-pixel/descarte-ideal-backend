import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateUserDto } from './dto/create-user.dto';
import * as bcrypt from 'bcrypt';

@Injectable()
export class UsersService {
  constructor(private readonly prisma: PrismaService) {}

  async findAll(companyId: string) {
    return this.prisma.user.findMany({
      where: { companyId },
      select: {
        id: true,
        name: true,
        email: true,
        status: true,
        role: { select: { id: true, name: true } },
        createdAt: true,
        lastLoginAt: true,
      },
      orderBy: { name: 'asc' },
    });
  }

  async create(companyId: string, dto: CreateUserDto) {
    const email = dto.email.toLowerCase();

    const exists = await this.prisma.user.findUnique({
      where: { companyId_email: { companyId, email } },
    });

    if (exists) {
      throw new ConflictException('E-mail já cadastrado nesta empresa');
    }

    if (dto.roleId) {
      const role = await this.prisma.role.findFirst({
        where: { id: dto.roleId, companyId },
      });

      if (!role) {
        throw new NotFoundException('Perfil não encontrado');
      }
    }

    const passwordHash = await bcrypt.hash(dto.password, 12);

    const user = await this.prisma.user.create({
      data: {
        companyId,
        roleId: dto.roleId,
        name: dto.name,
        email,
        passwordHash,
      },
      select: {
        id: true,
        name: true,
        email: true,
        status: true,
        role: { select: { id: true, name: true } },
        createdAt: true,
      },
    });

    return user;
  }
}
