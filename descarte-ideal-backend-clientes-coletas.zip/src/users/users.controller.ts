import { Body, Controller, Get, Post, Req, UseGuards } from '@nestjs/common';
import { UsersService } from './users.service';
import { CreateUserDto } from './dto/create-user.dto';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { PermissionsGuard } from '../auth/permissions.guard';
import { RequirePermissions } from '../auth/permissions.decorator';

@Controller('users')
@UseGuards(JwtAuthGuard, PermissionsGuard)
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Get()
  @RequirePermissions('users.view')
  findAll(@Req() req: any) {
    return this.usersService.findAll(req.user.companyId);
  }

  @Post()
  @RequirePermissions('users.create')
  create(@Req() req: any, @Body() dto: CreateUserDto) {
    return this.usersService.create(req.user.companyId, dto);
  }
}
