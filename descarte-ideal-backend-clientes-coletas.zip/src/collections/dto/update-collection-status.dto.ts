import { IsIn } from 'class-validator';

export class UpdateCollectionStatusDto {
  @IsIn([
    'REQUESTED',
    'SCHEDULED',
    'CONFIRMED',
    'IN_ROUTE',
    'COLLECTED',
    'NOT_COMPLETED',
    'CANCELLED',
  ])
  status!: string;
}
