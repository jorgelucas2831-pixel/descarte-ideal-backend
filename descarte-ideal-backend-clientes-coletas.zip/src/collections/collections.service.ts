import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateCollectionDto } from './dto/create-collection.dto';

@Injectable()
export class CollectionsService {
  constructor(private readonly prisma: PrismaService) {}

  findAll(companyId: string) {
    return this.prisma.collectionOrder.findMany({
      where: { companyId },
      include: {
        generator: true,
        collectionPoint: true,
      },
      orderBy: [
        { scheduledDate: 'asc' },
        { scheduledTime: 'asc' },
      ],
    });
  }

  async findOne(companyId: string, id: string) {
    const item = await this.prisma.collectionOrder.findFirst({
      where: { id, companyId },
      include: {
        generator: true,
        collectionPoint: true,
      },
    });
    if (!item) throw new NotFoundException('Coleta não encontrada');
    return item;
  }

  async create(companyId: string, dto: CreateCollectionDto) {
    const point = await this.prisma.collectionPoint.findFirst({
      where: {
        id: dto.collectionPointId,
        generatorId: dto.generatorId,
        active: true,
      },
      include: { generator: true },
    });

    if (!point || point.generator.companyId !== companyId) {
      throw new BadRequestException(
        'Ponto de coleta não pertence ao cliente informado',
      );
    }

    return this.prisma.collectionOrder.create({
      data: {
        companyId,
        generatorId: dto.generatorId,
        collectionPointId: dto.collectionPointId,
        scheduledDate: new Date(dto.scheduledDate),
        scheduledTime: dto.scheduledTime,
        status: dto.status ?? 'REQUESTED',
        priority: dto.priority ?? 0,
        notes: dto.notes,
      },
      include: {
        generator: true,
        collectionPoint: true,
      },
    });
  }

  async updateStatus(companyId: string, id: string, status: string) {
    await this.findOne(companyId, id);

    return this.prisma.collectionOrder.update({
      where: { id },
      data: { status },
      include: {
        generator: true,
        collectionPoint: true,
      },
    });
  }
}
