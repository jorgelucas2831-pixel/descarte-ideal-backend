import {
  Body,
  Controller,
  Get,
  Param,
  Patch,
  Post,
  Req,
  UseGuards,
} from '@nestjs/common';
import { CollectionsService } from './collections.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { PermissionsGuard } from '../auth/permissions.guard';
import { RequirePermissions } from '../auth/permissions.decorator';
import { CreateCollectionDto } from './dto/create-collection.dto';
import { UpdateCollectionStatusDto } from './dto/update-collection-status.dto';

@Controller('collections')
@UseGuards(JwtAuthGuard, PermissionsGuard)
export class CollectionsController {
  constructor(private readonly service: CollectionsService) {}

  @Get()
  @RequirePermissions('collections.view')
  findAll(@Req() req: any) {
    return this.service.findAll(req.user.companyId);
  }

  @Get(':id')
  @RequirePermissions('collections.view')
  findOne(@Req() req: any, @Param('id') id: string) {
    return this.service.findOne(req.user.companyId, id);
  }

  @Post()
  @RequirePermissions('collections.create')
  create(@Req() req: any, @Body() dto: CreateCollectionDto) {
    return this.service.create(req.user.companyId, dto);
  }

  @Patch(':id/status')
  @RequirePermissions('collections.edit')
  updateStatus(
    @Req() req: any,
    @Param('id') id: string,
    @Body() dto: UpdateCollectionStatusDto,
  ) {
    return this.service.updateStatus(req.user.companyId, id, dto.status);
  }
}
