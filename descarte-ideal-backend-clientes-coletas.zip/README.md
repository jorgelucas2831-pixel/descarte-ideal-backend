# Descarte Ideal — Backend

Backend base do ERP Descarte Ideal usando NestJS + PostgreSQL + Prisma + JWT.

## 1. Pré-requisitos

- Node.js 20+
- Docker Desktop
- npm

## 2. Instalação

```bash
npm install
cp .env.example .env
docker compose up -d
npx prisma generate
npx prisma migrate dev --name init
npm run db:seed
npm run start:dev
```

API:
http://localhost:3000/api

## 3. Login inicial

```text
POST /api/auth/login
Content-Type: application/json

{
  "email": "admin@descarteideal.local",
  "password": "Admin@123456"
}
```

O seed cria o perfil Administrador e todas as permissões.

## 4. Usuários

Listar:
```text
GET /api/users
Authorization: Bearer <TOKEN>
```

Criar:
```text
POST /api/users
Authorization: Bearer <TOKEN>
Content-Type: application/json

{
  "name": "Maria",
  "email": "maria@descarteideal.local",
  "password": "Senha@123456",
  "roleId": "<UUID_DO_PERFIL>"
}
```

## 5. Segurança

- Senhas armazenadas com bcrypt.
- JWT com expiração configurável.
- Multiempresa via companyId.
- Controle de acesso por permissões `modulo.acao`.
- Validação global de DTOs.
- O segredo JWT deve ser alterado antes de produção.
- A senha do usuário seed deve ser alterada imediatamente.

## Próximos módulos

1. Empresas/filiais
2. Clientes/geradores
3. Resíduos
4. Coletas
5. Pesagens
6. Lotes
7. Triagem
8. Estoque
9. Destinação
10. Vendas
11. Financeiro
12. Auditoria


## Módulo 1 — Clientes, pontos de coleta e coletas

Endpoints principais:

```text
GET    /api/customers
POST   /api/customers
GET    /api/customers/:id
PATCH  /api/customers/:id

GET    /api/customers/:id/collection-points
POST   /api/customers/:id/collection-points
PATCH  /api/customers/:id/collection-points/:pointId

GET    /api/collections
POST   /api/collections
GET    /api/collections/:id
PATCH  /api/collections/:id/status
```

Fluxo:

```text
Cliente/Gerador
      ↓
Ponto de coleta
      ↓
Agendamento
      ↓
Coleta
      ↓
Próximo módulo: veículo + motorista + pesagem
```

Antes de executar, instale as dependências e gere uma nova migration:

```bash
npm install
npx prisma generate
npx prisma migrate dev --name customers_collections
npm run db:seed
npm run start:dev
```
